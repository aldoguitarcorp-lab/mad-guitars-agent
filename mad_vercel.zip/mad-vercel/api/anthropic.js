const https = require('https');

module.exports = async function(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    // Parse body whether it's a string or already an object
    const bodyObj = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    const apiKey = bodyObj._apiKey;
    
    // Build clean payload without _apiKey
    const payload = {
      model: bodyObj.model || 'claude-sonnet-4-6',
      max_tokens: bodyObj.max_tokens || 1000,
      system: bodyObj.system,
      messages: bodyObj.messages
    };

    const postData = JSON.stringify(payload);

    const data = await new Promise((resolve, reject) => {
      const options = {
        hostname: 'api.anthropic.com',
        path: '/v1/messages',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01'
        }
      };
      const r = https.request(options, (resp) => {
        let raw = '';
        resp.on('data', c => raw += c);
        resp.on('end', () => {
          try { resolve({ status: resp.statusCode, body: JSON.parse(raw) }); }
          catch(e) { reject(new Error('Parse: ' + raw.substring(0, 200))); }
        });
      });
      r.on('error', reject);
      r.write(postData);
      r.end();
    });

    return res.status(data.status).json(data.body);
  } catch(err) {
    return res.status(500).json({ error: { message: err.message } });
  }
};
